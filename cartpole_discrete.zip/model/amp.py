import torch
import torch.nn as nn


# --- Networks ---
class Discriminator(nn.Module):
    """(s, s') → P(expert)"""
    def __init__(self, state_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim * 2, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )

    def forward(self, s, s_next):
        x = torch.cat([s, s_next], dim=-1)
        return self.net(x).squeeze(-1)


class Policy(nn.Module):
    """s → action distribution (Categorical)"""
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim)
        )

    def forward(self, s):
        return torch.distributions.Categorical(logits=self.net(s))


# --- Trajectory Collection ---
def collect_trajectory(env, policy, max_steps):
    """현재 policy로 agent 궤적 수집 (task reward 포함)"""
    states, actions, next_states, task_rewards = [], [], [], []
    state, _ = env.reset()
    state_t = torch.FloatTensor(state)

    for _ in range(max_steps):
        with torch.no_grad():
            dist = policy(state_t.unsqueeze(0))
            action = dist.sample().item()

        next_state, reward, terminated, truncated, _ = env.step(action)
        next_state_t = torch.FloatTensor(next_state)

        states.append(state_t)
        actions.append(action)
        next_states.append(next_state_t)
        task_rewards.append(reward)  # task reward 저장

        state_t = next_state_t
        if terminated or truncated:
            state, _ = env.reset()
            state_t = torch.FloatTensor(state)

    return (torch.stack(states),
            torch.tensor(actions),
            torch.stack(next_states),
            torch.tensor(task_rewards))


